import random

random.seed(3001)

def write_case(filename, n, m, min_choices, max_choices):
    with open(filename, "w") as f:
        f.write(f"{n} {m}\n")

        for _ in range(n):
            k = random.randint(min_choices, max_choices)
            k = min(k, m)

            slots = sorted(random.sample(range(1, m + 1), k))

            f.write(str(k))

            if slots:
                f.write(" " + " ".join(map(str, slots)))

            f.write("\n")


write_case(
    "data/secret/09_random_large.in",
    n=100,
    m=100,
    min_choices=1,
    max_choices=10
)

write_case(
    "data/secret/10_dense_large.in",
    n=300,
    m=300,
    min_choices=50,
    max_choices=120
)