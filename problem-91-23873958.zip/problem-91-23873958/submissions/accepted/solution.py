# Accepted solution for Internship Interview Scheduling
# Uses augmenting paths to find a maximum bipartite matching.

n, m = map(int, input().split())

availability = []

for _ in range(n):
    line = list(map(int, input().split()))
    k = line[0]
    availability.append(line[1:k + 1])

# match[slot] = student currently assigned to that slot
# -1 means the slot is currently unassigned.
match = [-1] * (m + 1)


def find_match(student, visited):
    """
    Try to assign this student to a slot.

    If a preferred slot is already occupied, try to move
    the currently assigned student to another available slot.
    """
    for slot in availability[student]:

        if visited[slot]:
            continue

        visited[slot] = True

        if match[slot] == -1 or find_match(match[slot], visited):
            match[slot] = student
            return True

    return False


scheduled = 0

for student in range(n):
    visited = [False] * (m + 1)

    if find_match(student, visited):
        scheduled += 1

print(scheduled)