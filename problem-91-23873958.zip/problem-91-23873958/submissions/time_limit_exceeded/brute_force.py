# Intentionally slow solution.
# Tries possible assignments recursively.
# Correct for small inputs but far too slow for large cases.

n, m = map(int, input().split())

availability = []

for _ in range(n):
    line = list(map(int, input().split()))
    k = line[0]
    availability.append(line[1:k + 1])

used = [False] * (m + 1)


def search(student):
    if student == n:
        return 0

    # Option 1: do not schedule this student
    best = search(student + 1)

    # Option 2: try every available unused slot
    for slot in availability[student]:
        if not used[slot]:
            used[slot] = True

            best = max(
                best,
                1 + search(student + 1)
            )

            used[slot] = False

    return best


print(search(0))