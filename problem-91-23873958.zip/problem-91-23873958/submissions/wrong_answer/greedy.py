# Wrong solution:
# Assigns each student to the first available slot.
# This fails because an earlier student may need to be moved
# to allow a better overall assignment.

n, m = map(int, input().split())

used = [False] * (m + 1)
scheduled = 0

for _ in range(n):
    line = list(map(int, input().split()))
    k = line[0]
    slots = line[1:k + 1]

    for slot in slots:
        if not used[slot]:
            used[slot] = True
            scheduled += 1
            break

print(scheduled)