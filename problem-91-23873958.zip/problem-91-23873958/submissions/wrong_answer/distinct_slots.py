# Wrong solution:
# Assumes the answer is simply the number of different slots
# that appear in at least one student's availability.

n, m = map(int, input().split())

available_slots = set()

for _ in range(n):
    line = list(map(int, input().split()))
    k = line[0]

    for slot in line[1:k + 1]:
        available_slots.add(slot)

print(min(n, len(available_slots)))