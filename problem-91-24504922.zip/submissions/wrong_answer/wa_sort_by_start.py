# WRONG: greedy by earliest START time. One long window that starts first
# blocks many short ones, so this undercounts.
import sys

data = sys.stdin.buffer.read().split()
n = int(data[0])
windows = sorted((int(data[1 + 2 * i]), int(data[2 + 2 * i])) for i in range(n))
count, last_finish = 0, -1
for s, f in windows:
    if s >= last_finish:
        count += 1
        last_finish = f
print(count)
