# WRONG: correct greedy order (earliest finish) but treats windows that merely
# touch (s == last finish) as overlapping, ignoring the half-open definition.
import sys

data = sys.stdin.buffer.read().split()
n = int(data[0])
windows = sorted((int(data[2 + 2 * i]), int(data[1 + 2 * i])) for i in range(n))
count, last_finish = 0, -1
for f, s in windows:
    if s > last_finish:  # should be >=
        count += 1
        last_finish = f
print(count)
