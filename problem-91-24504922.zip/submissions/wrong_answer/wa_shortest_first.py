# WRONG: greedy by shortest duration. A short window in the middle can
# overlap two long windows that are compatible with each other.
import sys

data = sys.stdin.buffer.read().split()
n = int(data[0])
windows = sorted(
    (int(data[2 + 2 * i]) - int(data[1 + 2 * i]), int(data[1 + 2 * i]), int(data[2 + 2 * i]))
    for i in range(n)
)
taken = []  # chosen (s, f) windows
for _, s, f in windows:
    # Take the window only if it overlaps nothing already taken.
    if all(f <= ts or s >= tf for ts, tf in taken):
        taken.append((s, f))
print(len(taken))
