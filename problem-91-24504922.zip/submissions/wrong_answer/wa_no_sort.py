# WRONG: applies the greedy rule in input order, assuming the minions are
# already sorted by finish time. The input is in no particular order.
import sys

data = sys.stdin.buffer.read().split()
n = int(data[0])
count, last_finish = 0, -1
for i in range(n):
    s, f = int(data[1 + 2 * i]), int(data[2 + 2 * i])
    if s >= last_finish:
        count += 1
        last_finish = f
print(count)
