# TOO SLOW: correct O(n^2) DP. Sort by finish; dp[i] = 1 + best dp[j] over all
# earlier windows j that finish before window i starts. Fine for small n, but
# n = 2*10^5 means ~2*10^10 steps.
import sys

data = sys.stdin.buffer.read().split()
n = int(data[0])
windows = sorted((int(data[2 + 2 * i]), int(data[1 + 2 * i])) for i in range(n))
dp = [1] * n
for i in range(n):
    f_i, s_i = windows[i]
    for j in range(i):
        if windows[j][0] <= s_i and dp[j] + 1 > dp[i]:
            dp[i] = dp[j] + 1
print(max(dp))
