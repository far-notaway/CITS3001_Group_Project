# TOO SLOW: right idea (earliest finish first) but implemented naively. Each
# round scans the whole remaining list for the minimum finish, then rebuilds
# the list without conflicting windows: O(n * answer), i.e. O(n^2) in the worst case.
import sys

data = sys.stdin.buffer.read().split()
n = int(data[0])
remaining = [(int(data[1 + 2 * i]), int(data[2 + 2 * i])) for i in range(n)]
count = 0
while remaining:
    s0, f0 = min(remaining, key=lambda w: w[1])  # earliest finish among the rest
    count += 1
    # Keep only windows that start at or after f0 (earlier ones conflict or are dominated).
    remaining = [(s, f) for s, f in remaining if s >= f0]
print(count)
