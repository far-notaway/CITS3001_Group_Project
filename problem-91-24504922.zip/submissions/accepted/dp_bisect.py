# Alternative accepted solution: weighted-interval-scheduling DP with unit
# weights, O(n log n). dp[i] = best count using the first i windows (sorted by
# finish). Binary search finds the last window finishing at or before s_i.
import sys
from bisect import bisect_right


def main():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    windows = sorted((int(data[2 + 2 * i]), int(data[1 + 2 * i])) for i in range(n))
    finishes = [f for f, _ in windows]
    dp = [0] * (n + 1)
    for i, (f, s) in enumerate(windows, start=1):
        j = bisect_right(finishes, s)  # number of windows with finish <= s
        dp[i] = max(dp[i - 1], dp[j] + 1)
    print(dp[n])


main()
