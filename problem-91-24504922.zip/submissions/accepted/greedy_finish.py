# Intended solution: greedy activity selection, O(n log n).
# Sort windows by earliest finish time, then take every window that starts
# at or after the finish time of the last window we took.
import sys


def main():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    # Pair each window as (finish, start) so sorting orders by finish time.
    windows = sorted((int(data[2 + 2 * i]), int(data[1 + 2 * i])) for i in range(n))
    count = 0
    last_finish = -1  # all start times are >= 0, so the first window is always allowed
    for f, s in windows:
        if s >= last_finish:  # half-open windows: touching is fine
            count += 1
            last_finish = f
    print(count)


main()
