#!/usr/bin/env python3
"""Validate canonical single-case input; exit 42 when valid and 43 otherwise."""

import sys


def fail(message):
    print(message, file=sys.stderr)
    raise SystemExit(43)


def integers(line, count, label):
    if not line.endswith(b"\n"):
        fail(label + ": expected an LF-terminated line")
    # Splitting on one literal space rejects tabs, doubled spaces, and padding.
    fields = line[:-1].split(b" ")
    if len(fields) != count:
        fail(label + ": incorrect number of fields")
    if any(not field.isdigit() or (len(field) > 1 and field[0] == ord("0"))
           for field in fields):
        fail(label + ": expected ASCII decimal integers without leading zeros")
    try:
        return [int(field) for field in fields]
    except ValueError:
        fail(label + ": invalid integer")


def main():
    n, m = integers(sys.stdin.buffer.readline(), 2, "header")
    if not 1 <= n <= 100000 or not 0 <= m <= 200000:
        fail("N or M out of bounds")
    for index in range(m):
        u, v, cost = integers(sys.stdin.buffer.readline(), 3, "cable " + str(index + 1))
        if not 1 <= u <= n or not 1 <= v <= n or not 1 <= cost <= 10 ** 9:
            fail("cable " + str(index + 1) + ": value out of bounds")
    if sys.stdin.buffer.read(1):
        fail("unexpected data after the last cable")
    raise SystemExit(42)


if __name__ == "__main__":
    main()
