#!/usr/bin/env python3
"""Incorrect attempt: minimise root-to-building path lengths instead of total cost."""

import heapq
import sys


def main():
    values = iter(map(int, sys.stdin.buffer.read().split()))
    n, m = next(values), next(values)
    graph = [[] for _ in range(n)]
    for _ in range(m):
        u, v, cost = next(values) - 1, next(values) - 1, next(values)
        graph[u].append((v, cost))
        graph[v].append((u, cost))

    infinity = 10 ** 30
    distance = [infinity] * n
    last_cable = [0] * n
    distance[0] = 0
    queue = [(0, 0)]
    while queue:
        length, u = heapq.heappop(queue)
        if length != distance[u]:
            continue
        for v, cost in graph[u]:
            candidate = length + cost
            if candidate < distance[v]:
                distance[v] = candidate
                last_cable[v] = cost
                heapq.heappush(queue, (candidate, v))
    if infinity in distance:
        print("IMPOSSIBLE")
    else:
        # Shortest paths from one root need not produce a minimum-cost network.
        print(sum(last_cable))


if __name__ == "__main__":
    main()
