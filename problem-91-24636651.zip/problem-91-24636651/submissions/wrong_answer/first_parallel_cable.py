#!/usr/bin/env python3
"""Incorrect attempt: assume repeated endpoint pairs describe the same cable."""

import sys


def main():
    values = iter(map(int, sys.stdin.buffer.read().split()))
    n, m = next(values), next(values)
    first = {}
    for _ in range(m):
        u, v, cost = next(values) - 1, next(values) - 1, next(values)
        pair = (min(u, v), max(u, v))
        # Discarding a later, cheaper parallel cable can change the answer.
        if pair not in first:
            first[pair] = cost
    edges = sorted((cost, u, v) for (u, v), cost in first.items())
    parent = list(range(n))
    size = [1] * n

    def find(x):
        while x != parent[x]:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    total = 0
    chosen = 0
    for cost, u, v in edges:
        u, v = find(u), find(v)
        if u == v:
            continue
        if size[u] < size[v]:
            u, v = v, u
        parent[v] = u
        size[u] += size[v]
        total += cost
        chosen += 1
    print(total if chosen == n - 1 else "IMPOSSIBLE")


if __name__ == "__main__":
    main()
