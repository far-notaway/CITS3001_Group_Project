#!/usr/bin/env python3
"""Incorrect attempt: return a minimum forest even when buildings are isolated."""

import sys


def main():
    values = iter(map(int, sys.stdin.buffer.read().split()))
    n, m = next(values), next(values)
    edges = []
    for _ in range(m):
        u, v, cost = next(values), next(values), next(values)
        edges.append((cost, u - 1, v - 1))
    parent = list(range(n))
    size = [1] * n

    def find(x):
        while x != parent[x]:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    total = 0
    for cost, u, v in sorted(edges):
        u, v = find(u), find(v)
        if u == v:
            continue
        if size[u] < size[v]:
            u, v = v, u
        parent[v] = u
        size[u] += size[v]
        total += cost
    # This forgets that every building must belong to the same component.
    print(total)


if __name__ == "__main__":
    main()
