#!/usr/bin/env python3
"""Incorrect attempt: buy the N - 1 cheapest cables without checking cycles."""

import sys


def main():
    values = iter(map(int, sys.stdin.buffer.read().split()))
    n, m = next(values), next(values)
    costs = []
    for _ in range(m):
        next(values)
        next(values)
        costs.append(next(values))
    if m < n - 1:
        print("IMPOSSIBLE")
    else:
        # The mistaken assumption is that the cable count ensures connectivity.
        costs.sort()
        print(sum(costs[:n - 1]))


if __name__ == "__main__":
    main()
