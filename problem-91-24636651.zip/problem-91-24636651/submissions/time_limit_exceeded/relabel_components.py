#!/usr/bin/env python3
"""Correct but slow Kruskal: merging components scans every building."""

import sys


def main():
    values = iter(map(int, sys.stdin.buffer.read().split()))
    n, m = next(values), next(values)
    edges = []
    for _ in range(m):
        u, v, cost = next(values), next(values), next(values)
        edges.append((cost, u - 1, v - 1))
    component = list(range(n))
    total = 0
    chosen = 0
    for cost, u, v in sorted(edges):
        old, new = component[u], component[v]
        if old == new:
            continue
        # This O(N) scan for each merge causes O(N^2) work on a connected graph.
        for vertex in range(n):
            if component[vertex] == old:
                component[vertex] = new
        total += cost
        chosen += 1
        if chosen == n - 1:
            break
    print(total if chosen == n - 1 else "IMPOSSIBLE")


if __name__ == "__main__":
    main()
