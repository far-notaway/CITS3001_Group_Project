#!/usr/bin/env python3
"""Kruskal's algorithm with union by rank and path compression."""

import sys


def main():
    values = iter(map(int, sys.stdin.buffer.read().split()))
    n = next(values)
    m = next(values)
    edges = []
    for _ in range(m):
        u, v, cost = next(values), next(values), next(values)
        edges.append((cost, u - 1, v - 1))
    edges.sort()

    # Each root represents one component of buildings already connected.
    parent = list(range(n))
    rank = [0] * n

    def find(vertex):
        # Path halving makes later searches for this component faster.
        while parent[vertex] != vertex:
            parent[vertex] = parent[parent[vertex]]
            vertex = parent[vertex]
        return vertex

    total = 0
    chosen = 0
    for cost, u, v in edges:
        root_u, root_v = find(u), find(v)
        if root_u == root_v:
            # This includes self-loops and cables that would form a cycle.
            continue
        if rank[root_u] < rank[root_v]:
            root_u, root_v = root_v, root_u
        parent[root_v] = root_u
        if rank[root_u] == rank[root_v]:
            rank[root_u] += 1
        total += cost
        chosen += 1
        if chosen == n - 1:
            break

    # A forest with N - 1 chosen cables is connected. For N = 1, 0 suffice.
    print(total if chosen == n - 1 else "IMPOSSIBLE")


if __name__ == "__main__":
    main()
